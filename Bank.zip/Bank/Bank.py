class Bank:
    def __init__(self):
        self.balance = 0

    def deposit(self):
        print("-------------------------------")
        amount = float(input("Enter amount to deposit: "))
        self.balance += amount
        print(f"Current Balance: ${self.balance}")
        print("-------------------------------")

    def withdraw(self):
        print("-------------------------------")
        print(f"Current Balance: ${self.balance}")
        amount = float(input("Enter amount to withdraw: "))
        if amount > self.balance:
            print("Sorry, you don't have enough money to withdraw.")
        else:
            self.balance -= amount
            print(f"You have successfully withdrawn ${amount}")
            print(f"Current Balance: ${self.balance}")
        print("-------------------------------")


        