from Bank import Bank

my_account = Bank()

is_running = True

while is_running:
    print("-------------------------------")
    print("type 1. Show balance")
    print("type 2. Deposit")
    print("type 3. Withdraw")
    print("type 0. Exit")
    print("-------------------------------")

    user = int(input(""))

    if user == 1:
        print("-------------------------------")
        print(f"Current Balance: ${my_account.balance}")
        print("-------------------------------")

    elif user == 2:
        my_account.deposit()

    elif user == 3:
        my_account.withdraw()

    elif user == 0:
        is_running = False
    else:
        print("Invalid option, please try again.")

print("Good bye")
