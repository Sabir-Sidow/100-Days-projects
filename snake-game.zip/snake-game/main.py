from turtle import Screen
from snake import Snake
from  food import Food
from scoreboard import Scoreboard
import time

sc = Screen()
sc.title("SNAKE GAME")
sc.setup(width=600, height=600)
sc.bgcolor("black")
sc.tracer(0)

snake = Snake()
food = Food()
scoreboard = Scoreboard()

sc.listen()
sc.onkey(key="Up", fun=snake.up)
sc.onkey(key="Down", fun=snake.down)
sc.onkey(key="Left", fun=snake.left)
sc.onkey(key="Right", fun=snake.right)

is_on = True

while is_on:
    sc.update()
    time.sleep(0.15)
    snake.move()

    if snake.head.distance(food) < 18:
        food.refresh()
        snake.extend()
        scoreboard.increase_score()

    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        is_on = False
        scoreboard.game_over()

    for segment in snake.segments[1:]:
        if snake.head.distance(segment) < 10:
            is_on = False
            scoreboard.game_over()




sc.exitonclick()