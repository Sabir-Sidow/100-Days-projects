STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280
from turtle import Turtle

class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("turtle")
        self.penup()
        self.goto_start()
        self.setheading(90)

    def go_up(self):
        """Move the player forward (upwards)"""
        self.forward(MOVE_DISTANCE)

    def goto_start(self):
        """Reset the turtle to the starting position"""
        self.goto(STARTING_POSITION)

    def is_at_finish_line(self):
        """Check if the player reached the finish line"""
        return self.ycor() > FINISH_LINE_Y



