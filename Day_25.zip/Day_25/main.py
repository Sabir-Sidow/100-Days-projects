import turtle
import pandas

sc = turtle.Screen()
sc.title("U.S states Game")
image = "blank_states_img.gif"
sc.addshape(image)
turtle.shape(image)


data = pandas.read_csv("50_states.csv")
all_states = data.state.to_list()
guesswd_states = []

while len(guesswd_states) < 50:
    answer_state = sc.textinput(
        title=f"{len(guesswd_states)}/50 states Correct",
        prompt="what's another state's name?").title()

    if answer_state is None or answer_state.title() == "Exit":
        missing_states = []
        for state in all_states:
            if state not in guesswd_states:
                missing_states.append(state)
        new_data = pandas.DataFrame(missing_states)
        new_data.to_csv("states_to_learn.csv")
        break

    if answer_state in all_states and answer_state not in guesswd_states:
        guesswd_states.append(answer_state)
        t = turtle.Turtle()
        t.hideturtle()
        t.penup()
        state_data = data[data.state == answer_state]
        t.goto(int(state_data.x.item()), int(state_data.y.item()))
        t.write(state_data.state.item())



















