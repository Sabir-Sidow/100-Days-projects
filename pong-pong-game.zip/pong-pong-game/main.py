from turtle import Turtle, Screen
from  paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
import time


sc = Screen()
sc.bgcolor("black")
sc.screensize(800, 600)
sc.title("PONG PONG" )
sc.tracer(0)

left_paddle = Paddle()
right_paddle = Paddle()
left_paddle.goto(-350, 0)
right_paddle.goto(350, 0)

ball = Ball()
scoreboard = Scoreboard()

sc.listen()
sc.onkey(right_paddle.go_up, "Up")
sc.onkey(right_paddle.go_down, "Down")
sc.onkey(left_paddle.go_up, "w")
sc.onkey(left_paddle.go_down, "s")

is_on = True
while is_on:
    time.sleep(ball.move_speed)
    sc.update()
    ball.move()

    if ball.ycor() > 288 or ball.ycor() < -288:
        ball.bounce_y()

    if ball.distance(right_paddle) < 50 and ball.xcor() > 320 or ball.distance(left_paddle) < 50 and ball.xcor() > -320:
        ball.bounce_x()

    if ball.xcor() > 380:
        ball.reset_position()
        scoreboard.l_point()

    if ball.xcor() < -380:
        ball.reset_position()
        scoreboard.r_point()


sc.exitonclick()